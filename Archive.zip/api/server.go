package api

import (
	"fmt"
	"github.com/ranomuhamad98/ep_sleep_latency/api/controllers"
)

var server = controllers.Server{}

func Run() {	
	fmt.Println("We are getting the env values")
	server.Initialize()
	server.Run(":8180")
}

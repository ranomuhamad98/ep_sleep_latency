package main

import "github.com/ranomuhamad98/ep_sleep_latency/api"

func main() {
	api.Run()
}